package com.jph.takephoto.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.jph.takephoto.compress.CompressConfig;
import com.jph.takephoto.model.CropOptions;
import com.jph.takephoto.model.InvokeParam;
import com.jph.takephoto.model.MultipleCrop;
import com.jph.takephoto.model.TException;
import com.jph.takephoto.permission.InvokeListener;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class TakePhotoInvocationHandler implements InvocationHandler{
    private TakePhoto delegate;
    private InvokeListener listener;
    public static TakePhotoInvocationHandler of(InvokeListener listener){
        return new TakePhotoInvocationHandler(listener);
    }

    private TakePhotoInvocationHandler(InvokeListener listener) {
        this.listener=listener;
    }

    /**
     * 绑定委托对象并返回一个代理类
     * @param delegate
     * @return
     */
    public Object bind(TakePhoto delegate) {
        this.delegate = delegate;
        return Proxy.newProxyInstance(delegate.getClass().getClassLoader(), delegate.getClass().getInterfaces(), this);
    }
    @Override
    public Object invoke(Object proxy, Method method, Object[] args)
            throws Throwable {
        listener.invoke(new InvokeParam(proxy,method,args));
        if(true){
            return new TakePhoto() {
                @Override
                public void onPickMultiple(int limit) {

                }

                @Override
                public void onPickMultipleWithCrop(int limit, CropOptions options) {

                }

                @Override
                public void onPickFromDocuments() {

                }

                @Override
                public void onPickFromDocumentsWithCrop(Uri outPutUri, CropOptions options) {

                }

                @Override
                public void onPickFromGallery() {

                }

                @Override
                public void onPickFromGalleryWithCrop(Uri outPutUri, CropOptions options) {

                }

                @Override
                public void onPickFromCapture(Uri outPutUri) {

                }

                @Override
                public void onPickFromCaptureWithCrop(Uri outPutUri, CropOptions options) {

                }

                @Override
                public void onCrop(Uri imageUri, Uri outPutUri, CropOptions options) throws TException {

                }

                @Override
                public void onCrop(MultipleCrop multipleCrop, CropOptions options) throws TException {

                }

                @Override
                public TakePhoto onEnableCompress(CompressConfig config, boolean showCompressDialog) {
                    return null;
                }

                @Override
                public void onCreate(Bundle savedInstanceState) {

                }

                @Override
                public void onSaveInstanceState(Bundle outState) {

                }

                @Override
                public void onActivityResult(int requestCode, int resultCode, Intent data) {

                }
            };
        }
        return method.invoke(delegate, args);

    }
}