package com.jph.takephoto.permission;

import com.jph.takephoto.model.InvokeParam;

import java.lang.reflect.Method;

/**
 * 授权管理回调
 */
public interface InvokeListener {
    PermissionManager.TPermissionType invoke(InvokeParam invokeParam);
}
