package com.jph.takephoto.permission;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;

import com.jph.takephoto.uitl.TConstant;

import java.lang.reflect.Method;
import java.util.ArrayList;

/**
 * Created by penn on 16/9/22.
 */
public class PermissionManager {
    public enum TPermission {
        CAMERA(Manifest.permission.WRITE_EXTERNAL_STORAGE),
        STORAGE(Manifest.permission.CAMERA);
        String stringValue;

        TPermission(String stringValue) {
            this.stringValue = stringValue;
        }

        public String stringValue() {
            return stringValue;
        }
    }

    public enum TPermissionType {
        GRANTED("已授权"),
        DENIED("未授权"),
        WAIT("等待授权"),
        ONLY_CAMERA_DENIED("没有拍照权限"),
        ONLY_STORAGE_DENIED("没有读写SD卡权限");
        String stringValue;

        TPermissionType(String stringValue) {
            this.stringValue = stringValue;
        }

        public String stringValue() {
            return stringValue;
        }
    }

    /**
     * 检查当前应用是否被授予相应权限
     *
     * @param activity
     * @param method
     * @return
     */
    public static TPermissionType checkPermission(@NonNull Activity activity, @NonNull Method method) {
        String methodName = method.getName();

        boolean cameraGranted = true, storageGranted = ContextCompat.checkSelfPermission(activity, TPermission.STORAGE.stringValue()) == PackageManager.PERMISSION_GRANTED ? true : false;

        if (TextUtils.equals(methodName, "onPickFromCapture") || TextUtils.equals(methodName, "onPickFromCaptureWithCrop")) {
            cameraGranted = ContextCompat.checkSelfPermission(activity, TPermission.CAMERA.stringValue()) == PackageManager.PERMISSION_GRANTED ? true : false;
        }

        boolean granted = storageGranted && cameraGranted;
        if (!granted) {
            ArrayList<String> permissions = new ArrayList<>();
            if (!storageGranted) permissions.add(TPermission.STORAGE.stringValue());
            if (!cameraGranted) permissions.add(TPermission.CAMERA.stringValue());
            requestPermission(activity, (String[]) permissions.toArray());
        }
        return granted ? TPermissionType.GRANTED : TPermissionType.WAIT;
    }

    public static void requestPermission(@NonNull Activity activity, @NonNull String[] permissions) {
        ActivityCompat.requestPermissions(activity, permissions, TConstant.PERMISSION_REQUEST_TAKE_PHOTO);
    }

    public static TPermissionType onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == TConstant.PERMISSION_REQUEST_TAKE_PHOTO) {
            boolean cameraGranted = true, storageGranted = true;
            for (int i = 0, j = permissions.length; i < j; i++) {
                if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                    if (permissions[i] == TPermission.STORAGE.stringValue()) {
                        storageGranted = false;
                    } else if (permissions[i] == TPermission.STORAGE.stringValue()) {
                        cameraGranted = false;
                    }
                }
            }
            if (cameraGranted && storageGranted) return TPermissionType.GRANTED;
            if (!cameraGranted && storageGranted) return TPermissionType.ONLY_CAMERA_DENIED;
            if (!storageGranted && cameraGranted) return TPermissionType.ONLY_STORAGE_DENIED;
            if(!storageGranted&&!cameraGranted)return TPermissionType.DENIED;
        }
        return TPermissionType.WAIT;
    }
}
